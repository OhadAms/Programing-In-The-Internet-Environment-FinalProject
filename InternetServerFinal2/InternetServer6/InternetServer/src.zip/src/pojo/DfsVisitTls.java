package pojo;

import java.io.Serializable;
import java.util.*;

public class DfsVisitTls<T> implements Serializable {
    // TLS - Thread Local Storage
    private ThreadLocal<Stack<Node<T>>> workingStack;
    private ThreadLocal<Set<Node<T>>> finished;

    public DfsVisitTls(){
//        workingStack = ThreadLocal.withInitial(() -> new Stack<Node<T>>());
        workingStack = ThreadLocal.withInitial(Stack::new);
        finished = ThreadLocal.withInitial(LinkedHashSet::new);
    }

    public Set<T> traverse(Traversable<T> aTraversable){
        threadLocalPush(aTraversable.getRoot());
        while (!threadLocalIsEmpty()){
            Node<T> removed = threadLocalPop();
            finished.get().add(removed);
             Collection<Node<T>> reachableNodes = aTraversable.getReachableNodes(removed);
             for(Node<T> reachableNode :reachableNodes){
                 if (!finished.get().contains(reachableNode) &&
                 !workingStack.get().contains(reachableNode)){
                     threadLocalPush(reachableNode);
                 }
             }
        }
        Set<T> blackSet = new LinkedHashSet<>();
        for (Node<T> node: finished.get())
            blackSet.add(node.getData());
        finished.get().clear();
        return blackSet;


    }

    private void threadLocalPush(Node<T> node){
        workingStack.get().push(node);
    }

    private Node<T> threadLocalPop(){
        return workingStack.get().pop();
    }

    private boolean threadLocalIsEmpty(){
        return workingStack.get().isEmpty();
    }
}
